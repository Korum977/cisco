﻿using System;

namespace pr1
{
    public class Singleton
    {
        public interface ILogger
        {
            void Info(string message);
            void Error(string message);
        }

        public class Logger : ILogger
        {
            private static Logger instance;

            private Logger() { }

            public static Logger Instance
            {
                get
                {
                    if (instance == null)
                    {
                        instance = new Logger();
                    }
                    return instance;
                }
            }

            public void Error(string message)
            {
                Console.WriteLine($"Error: {message}");
            }

            public void Info(string message)
            {
                Console.WriteLine($"Info: {message}");
            }
        }
    }
}
