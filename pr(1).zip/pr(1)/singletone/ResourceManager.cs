﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace pr1.singlotes
{
    class ResourceManager
    {
        private static ResourceManager instance;
        List<Thread> threads = new List<Thread>() { };

        private ResourceManager()
        {

        }
        public static ResourceManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ResourceManager();
                }
                return instance;
            }
        }

        public void addThread(Thread t)
        {
            threads.Add(t);
        }
        public void execute()
        {
            threads.ForEach(startThread);
        }

        public void startThread(Thread e)
        {
            e.Start();
            e.Join();
        }


    }
}
