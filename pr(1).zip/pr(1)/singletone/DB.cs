﻿using System;
using System.Data.SqlClient;

namespace pr1.singlotes
{
    public class DB
    {
        private static DB instance;
        SqlConnection conn = null;

        private DB(string con_ = null)
        {
            string connectionString = con_ != null ? con_ : 
                "Data Source=ServerName;Initial Catalog=DatabaseName;" +
                "User ID=UserName;Password=Password";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
        }

        internal object Getdata(string v)
        {
            throw new NotImplementedException();
        }

        public static DB Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DB();
                }
                return instance;
            }
        }


        public void Disconnect()
        {
            conn.Close();
        }
    }
}
