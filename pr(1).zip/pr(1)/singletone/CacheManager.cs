﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1.singlotes
{
    class CacheManager
    {
        private static CacheManager instance;
        private Dictionary<string, object> data;

        private CacheManager()
        {
            data = new Dictionary<string, object>();
        }

        public static CacheManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CacheManager();
                }
                return instance;
            }
        }

        public object GetData(string key, Func<object> dataCallback)
        {
            if (!data.ContainsKey(key))
            {
                var result = dataCallback.Invoke();
                data[key] = result;
                return result;
            }
            return data[key];
        }
    }
}