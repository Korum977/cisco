﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1.singlotes
{

    class AppSettings
    {
        private Dictionary<string, string> configFields = 
            new Dictionary<string, string>();


        private static AppSettings instance;
        private AppSettings() { }

        public static AppSettings Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AppSettings();
                }
                return instance;
            }
        }


        public void AddField(string key, string data)
        {
            if (configFields.ContainsKey(key))
            {
                throw new ArgumentException($"Поле с именем '{key}' уже существует.");
            }

            configFields.Add(key, data);
        }

        public string GetField(string key)
        {
            if (configFields.TryGetValue(key, out string value))
            {
                return value;
            }

            throw new Exception($"Поле с именем  '{key}' не найдено.");
        }
    }
}

