﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1
{
    public interface IWeatherObserver
    {
        void Update(IWeatherReport report);
    }
    // Конкретный наблюдатель погоды
    public class ConcreteWeatherObserver : IWeatherObserver
    {
        private string name;
        public ConcreteWeatherObserver(string name)
        {
            this.name = name;
        } 
        public void Update(IWeatherReport report)
        {
            Console.WriteLine($"{name} получил обновленный отчет о погоде.Температура: { report.Temperature}°C");
        }
    }
    // Интерфейс погодного отчета
    public interface IWeatherReport
    {
        int Temperature { get; }
    }
    // Конкретный погодный отчет
    public class ConcreteWeatherReport : IWeatherReport
    {
        private int temperature;
        private List<IWeatherObserver> observers = new
       List<IWeatherObserver>();
        public int Temperature
        {
            get { return temperature; }
        }
        public void SetTemperature(int temperature)
        {
            this.temperature = temperature;
            NotifyObservers();
        }
        public void AddObserver(IWeatherObserver observer)
        {
            observers.Add(observer);
        }
        public void RemoveObserver(IWeatherObserver observer)
        {
            observers.Remove(observer);
        }
        private void NotifyObservers()
        {
            foreach (var observer in observers)
            {
                observer.Update(this);
            }
        }
    }

}
