﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1
{
    // Подсистема 1: Управление товарами
    class ProductSubsystem
    {
        
        public void AddProductToCart(int productId)
        {
            
            Console.WriteLine($"Товар с ID {productId} добавлен в корзину");


        }
        public void RemoveProductFromCart(int productId)
        {
            
            Console.WriteLine($"Товар с ID {productId} удален из корзины");
        }

        internal bool GetEnought(int productId)
        {
            return true;
        }
    }
    // Подсистема 2: Оформление заказа
    class OrderSubsystem
    {
        List<int> orders = new List<int>();

        public void CreateOrder(int order)
        {
            orders.Add(order);
            Console.WriteLine("Заказ создан");
        }
        public void ProcessPayment(int order)
        {
            Console.WriteLine("Платеж обработан");
        }

        public void GetHistory()
        {
            Console.WriteLine(string.Join<int>(", ", orders.ToArray()));
        }
    }

    // Подсистема 3: Доставка
    class DeliverySubsystem
    {
        public void CreateDelivery()
        {
            Console.WriteLine("Доставка запланирована");
        }
        public void ProcessDelivery()
        {
            Console.WriteLine("Доставка завершена");
        }

    }


    // Фасад: упрощает взаимодействие с подсистемами
    class OnlineShopFacade
    {
        private ProductSubsystem productSubsystem;
        private OrderSubsystem orderSubsystem;
        private DeliverySubsystem deliverySubsystem; 
        public OnlineShopFacade()
        {
            productSubsystem = new ProductSubsystem();
            orderSubsystem = new OrderSubsystem();
            deliverySubsystem = new DeliverySubsystem();
        }
        public void BuyProduct(int productId,bool DeliveryStatus)
        {
            if (productSubsystem.GetEnought(productId))
            {
                productSubsystem.AddProductToCart(productId);
                orderSubsystem.CreateOrder(productId);
                orderSubsystem.ProcessPayment(productId);
                if (DeliveryStatus)
                {
                    deliverySubsystem.CreateDelivery();
                    deliverySubsystem.ProcessDelivery();
                }
                productSubsystem.RemoveProductFromCart(productId);
                Console.WriteLine("Заказ завершен");
            }
            else
            {
                Console.WriteLine("Заказ завершен с ошибками");
            }

        }

        public void GetHistoryOrders()
        {
            Console.WriteLine("История заказов: \n");
            orderSubsystem.GetHistory();
        }
    }

}
