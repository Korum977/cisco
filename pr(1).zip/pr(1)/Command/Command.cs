﻿using System;

namespace pr1.command
{





    // Абстрактный класс команды
    abstract class Command
    {
        public abstract void Execute();
        public abstract void Cancel();
    }

    // Конкретная команда для включения света
    class LightOnCommand : Command
    {
        private readonly Light _light;
        public LightOnCommand(Light light)
        {
            _light = light;
        }
        public override void Execute()
        {
            _light.TurnOn();
        }
        public override void Cancel()
        {
            _light.Cancel();
        }
    }
    // Конкретная команда для выключения света
    class LightOffCommand : Command
    {
        private readonly Light _light;
        public LightOffCommand(Light light)
        {
            _light = light;
        }
        public override void Execute()
        {
            _light.TurnOff();
        }
        public override void Cancel()
        {
            _light.Cancel();
        }
    }


    // Конкретная команда для включения Молний
    class WexOnCommand : Command
    {
        private readonly Wex _Wex;
        public WexOnCommand(Wex Wex)
        {
            _Wex = Wex;
        }
        public override void Execute()
        {
            _Wex.TurnOn();
        }
        public override void Cancel()
        {
            _Wex.Cancel();
        }
    }
    // Конкретная команда для выключения Молний
    class WexOffCommand : Command
    {
        private readonly Wex _Wex;
        public WexOffCommand(Wex Wex)
        {
            _Wex = Wex;
        }
        public override void Execute()
        {
            _Wex.TurnOff();
        }
        public override void Cancel()
        {
            _Wex.Cancel();
        }
    }

    // Класс инвокера
    class Invoker
    {
        private Command _command;
        public void SetCommand(Command command)
        {
            _command = command;
        }
        public void ExecuteCommand()
        {
            _command.Execute();
        }
        public void CancelCommand()
        {
            _command.Cancel();
        }
    }

    // Класс-получатель
    class Light
    {
        public void TurnOn()
        {
            Console.WriteLine("Свет включен.");
        }
        public void TurnOff()
        {
            Console.WriteLine("Свет выключен.");
        }
        public void Cancel()
        {
            Console.WriteLine("Свет отменен.");
        }
    }

    class Wex
    {
        public void TurnOn()
        {
            Console.WriteLine("Молнии включены.");
        }
        public void TurnOff()
        {
            Console.WriteLine("Молнии выключены.");
        }
        public void Cancel()
        {
            Console.WriteLine("Молнии отменены.");
        }
    }

}
