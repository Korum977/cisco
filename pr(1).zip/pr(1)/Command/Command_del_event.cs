﻿using pr1.command;
using pr1.singlotes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_1_.Command
{
    class Light
    {
        public void call(ICommand command) {


            switch (command.GetType().Name)
            {
                case "TurnOn":
                    TurnOn();
                    break;
                case "TurnOff":
                    TurnOff();
                    break;
                case "Cancel":
                    Cancel();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }

        public void TurnOn()
        {
            Console.WriteLine("Свет включен.");
        }
        public void TurnOff()
        {
            Console.WriteLine("Свет выключен.");
        }
        public void Cancel()
        {
            Console.WriteLine("Свет отменен.");
        }
    }

    class Wex
    {
        public void call(ICommand command)
        {


            switch (command.GetType().Name)
            {
                case "TurnOn":
                    TurnOn();
                    break;
                case "TurnOff":
                    TurnOff();
                    break;
                case "Cancel":
                    Cancel();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }

        public void TurnOn()
        {
            Console.WriteLine("Молнии включены.");
        }
        public void TurnOff()
        {
            Console.WriteLine("Молнии выключены.");
        }
        public void Cancel()
        {
            Console.WriteLine("Молнии отменены.");
        }
    }


    public interface ICommand
    {
         void Execute();
        void Cancel();
    }

    // Конкретная команда для включения света
    class LightOnCommand : ICommand
    {
        private readonly Light _light;
        public LightOnCommand(Light light)
        {
            _light = light;
        }
        public  void Execute()
        {
            _light.TurnOn();
        }
        public  void Cancel()
        {
            _light.Cancel();
        }
    }
    // Конкретная команда для выключения света
    class LightOffCommand : ICommand
    {
        private readonly Light _light;
        public LightOffCommand(Light light)
        {
            _light = light;
        }
        public  void Execute()
        {
            _light.TurnOff();
        }
        public  void Cancel()
        {
            _light.Cancel();
        }
    }


    // Конкретная команда для включения Молний
    class WexOnCommand : ICommand
    {
        private readonly Wex _Wex;
        public WexOnCommand(Wex Wex)
        {
            _Wex = Wex;
        }
        public  void Execute()
        {
            _Wex.TurnOn();
        }
        public  void Cancel()
        {
            _Wex.Cancel();
        }
    }
    // Конкретная команда для выключения Молний
    class WexOffCommand : ICommand
    {
        private readonly Wex _Wex;
        public WexOffCommand(Wex Wex)
        {
            _Wex = Wex;
        }
        public  void Execute()
        {
            _Wex.TurnOff();
        }
        public  void Cancel()
        {
            _Wex.Cancel();
        }
    }

    // Инициатор команд
    public class Invoker
    {
        public event Action<ICommand> LightOnCommand;
        public event Action<ICommand> LightOffCommand;

        public event Action<ICommand> WexOnCommand;
        public event Action<ICommand> WexOffCommand;

        internal void ExecuteCommand(ICommand command)
        {
            command.Execute();  
        }
    }

}
