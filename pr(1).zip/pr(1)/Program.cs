﻿using pr_1_.Command;
using pr1.command;
using pr1.singlotes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace pr1
{
    class Program
    {
        static void Main(string[] args)
        {
            Singleton.Logger logger = Singleton.Logger.Instance;
            DB db = DB.Instance;
            CacheManager cache = CacheManager.Instance;
            logger.Error("test");
            logger.Info("test");

            //var users = cache.GetData("users", () => {

            //    return db.Getdata("users");
            //});




            //db.Disconnect();





            //ConcreteWeatherReport cwr = new ConcreteWeatherReport();
            //ConcreteWeatherObserver cwo_time = new ConcreteWeatherObserver("time");
            //ConcreteWeatherObserver cwo_value = new ConcreteWeatherObserver("value");
            //ConcreteWeatherObserver cwo_solar = new ConcreteWeatherObserver("solar");

            //cwr.AddObserver(cwo_time);
            //cwr.AddObserver(cwo_value);
            //cwr.AddObserver(cwo_solar);

            //cwr.SetTemperature(12);

            OnlineShopFacade shop = new OnlineShopFacade();
            //Покупка товара с использованием фасада
            shop.BuyProduct(123, false);
            shop.BuyProduct(321, true);
            shop.GetHistoryOrders();


            //// Создаем объекты
            //Light light = new Light();
            //LightOnCommand lightOn = new LightOnCommand(light);
            //LightOffCommand lightOff = new LightOffCommand(light);
            //Invoker remote = new Invoker();
            //// Устанавливаем и выполняем команду включения света
            //remote.SetCommand(lightOn);
            //remote.ExecuteCommand();
            //remote.CancelCommand();
            //// Устанавливаем и выполняем команду выключения
            //// света
            //remote.SetCommand(lightOff);
            //remote.ExecuteCommand();
            //remote.CancelCommand();

            // Создаем инициатор команд
            //pr_1_.Command.Invoker invoker = new pr_1_.Command.Invoker();
            //pr_1_.Command.Light light = new pr_1_.Command.Light();
            //pr_1_.Command.Wex wex = new pr_1_.Command.Wex();


            //// Создаем команды
            //ICommand command1 = new pr_1_.Command.LightOnCommand(light);
            //ICommand command2 = new pr_1_.Command.LightOffCommand(light);

            //ICommand command3 = new pr_1_.Command.WexOffCommand(wex);
            //ICommand command4 = new pr_1_.Command.WexOnCommand(wex);

            //// Подписываемся на событие
            //invoker.LightOnCommand += light.call;
            //invoker.LightOffCommand += light.call;

            //invoker.WexOnCommand += wex.call;
            //invoker.WexOffCommand += wex.call;


            //// Выполняем команды
            //invoker.ExecuteCommand(command1);
            //invoker.ExecuteCommand(command2);
            //invoker.ExecuteCommand(command3);
            //invoker.ExecuteCommand(command4);
        }

    }
    }

