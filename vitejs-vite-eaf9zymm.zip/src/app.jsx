import { LocationProvider, Router } from 'preact-iso';
import { useState } from 'react';
import { gsap } from 'gsap';
import Header from './components/Header';
import Hero from './components/Hero';
import { menuItems } from './data/menuItems';
import News from './components/News';
import BottomNavigation from './components/BottomNavigation';
import MenuSection from './components/MenuSection';
import NotFound from './components/NotFound';

// Home Page Component
const HomePage = () => (
  <div className="space-y-6">
    <Hero />
    <MenuSection
      sectionId="organization"
      title="Сведения об образовательной организации"
      icon="info"
      items={menuItems.organization}
    />
    <MenuSection
      sectionId="studentServices"
      title="Для студента"
      icon="school"
      items={menuItems.student}
    />
    <MenuSection
      sectionId="resources"
      title="Наши ресурсы"
      icon="hub"
      items={menuItems.resources}
    />
  </div>
);

// News Page Component
const NewsPage = () => (
  <div className="space-y-6">
    <News />
  </div>
);

// Schedule Page Component
const SchedulePage = () => (
  <div className="space-y-6">
    <h2 className="text-2xl font-bold text-gray-900">Расписание</h2>
    <div className="grid gap-4">
      <a
        href="https://disk.yandex.ru/d/dFUTahZmsxGDlw"
        target="_blank"
        rel="noopener noreferrer"
        className="p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all hover:bg-red-50 group"
      >
        <div className="flex items-center space-x-4">
          <span className="material-icons text-red-800 group-hover:text-red-900">
            schedule
          </span>
          <h3 className="font-semibold text-gray-800 group-hover:text-red-800">
            Расписание занятий (1 и 2 корпус)
          </h3>
        </div>
      </a>
      <a
        href="https://disk.yandex.ru/d/hzcEilskRIbBgw"
        target="_blank"
        rel="noopener noreferrer"
        className="p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all hover:bg-red-50 group"
      >
        <div className="flex items-center space-x-4">
          <span className="material-icons text-red-800 group-hover:text-red-900">
            schedule
          </span>
          <h3 className="font-semibold text-gray-800 group-hover:text-red-800">
            Расписание занятий (3 корпус)
          </h3>
        </div>
      </a>
      <a
        href="https://yadi.sk/d/XSpVS1vJdi43m"
        target="_blank"
        rel="noopener noreferrer"
        className="p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all hover:bg-red-50 group"
      >
        <div className="flex items-center space-x-4">
          <span className="material-icons text-red-800 group-hover:text-red-900">
            event_note
          </span>
          <h3 className="font-semibold text-gray-800 group-hover:text-red-800">
            Расписание экзаменов
          </h3>
        </div>
      </a>
    </div>
  </div>
);

// Profile Page Component
const ProfilePage = () => (
  <div className="space-y-6">
    <h2 className="text-2xl font-bold text-gray-900">Профиль</h2>
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center space-x-4 mb-6">
        <span className="material-icons text-gray-400 text-4xl">
          account_circle
        </span>
        <div>
          <h3 className="font-semibold text-gray-800 text-lg">Гость</h3>
          <p className="text-gray-500">Войдите в систему</p>
        </div>
      </div>
      <button className="w-full bg-red-800 text-white py-3 px-4 rounded-lg hover:bg-red-900 transition-colors font-medium">
        Войти
      </button>
    </div>
  </div>
);

export const App = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <LocationProvider>
      <div className="min-h-screen bg-gray-50">
        <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

        <main className="container mx-auto px-4 pt-20 pb-24">
          <div className="max-w-2xl mx-auto">
            <Router>
              <HomePage path="/" />
              <NewsPage path="/news" />
              <SchedulePage path="/schedule" />
              <ProfilePage path="/profile" />
              <NotFound default />
            </Router>
          </div>
        </main>

        <BottomNavigation />
      </div>
    </LocationProvider>
  );
};

export default App;
