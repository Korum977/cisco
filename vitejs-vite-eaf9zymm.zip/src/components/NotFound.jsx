const NotFound = () => (
  <div className="text-center py-10">
    <h1 className="text-2xl font-bold mb-4">404 - Страница не найдена</h1>
    <p>Запрашиваемая страница не существует.</p>
    <a href="/" className="text-blue-600 hover:underline mt-4 inline-block">
      Вернуться на главную
    </a>
  </div>
);

export default NotFound;
