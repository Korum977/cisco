import { useLocation } from 'preact-iso';

const BottomNavigation = () => {
  const location = useLocation();

  const navItems = [
    { icon: 'home', text: 'Главная', path: '/' },
    { icon: 'article', text: 'Новости', path: '/news' },
    { icon: 'calendar_today', text: 'Расписание', path: '/schedule' },
    { icon: 'person', text: 'Профиль', path: '/profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-around py-2">
          {navItems.map((item) => (
            <a
              key={item.text}
              href={item.path}
              className={`
                text-center px-4 py-2 rounded-lg transition-colors
                ${
                  location.path === item.path
                    ? 'text-red-800 bg-red-50'
                    : 'text-gray-700 hover:text-red-800 hover:bg-red-50'
                }
              `}
            >
              <span className="material-icons">{item.icon}</span>
              <p className="text-xs mt-1 font-medium">{item.text}</p>
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default BottomNavigation;
