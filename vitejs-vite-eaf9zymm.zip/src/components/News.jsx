import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { newsItems } from '../data/newsItems';

const News = () => {
  const newsRef = useRef(null);

  useEffect(() => {
    gsap.from(newsRef.current.children, {
      y: 30,
      opacity: 0,
      duration: 0.8,
      stagger: 0.2,
      ease: 'power2.out',
    });
  }, []);

  return (
    <section id="news" className="mb-8">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 flex items-center border-b border-gray-100">
          <span className="material-icons text-red-800 text-2xl mr-3">
            newspaper
          </span>
          <h3 className="text-lg font-semibold text-gray-900">Новости</h3>
        </div>

        <div ref={newsRef} className="divide-y divide-gray-100">
          {newsItems.map((item) => (
            <article
              key={item.id}
              className="p-6 hover:bg-red-50 transition-colors group"
            >
              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <h4 className="text-lg font-semibold text-gray-800 group-hover:text-red-800">
                    {item.title}
                  </h4>
                  <span className="text-sm text-gray-500 whitespace-nowrap ml-4">
                    {item.date}
                  </span>
                </div>
                <p className="text-gray-600">{item.description}</p>
                {item.link && (
                  <a
                    href={item.link}
                    className="inline-flex items-center text-red-800 hover:text-red-900 text-sm font-medium"
                  >
                    Подробнее
                    <span className="material-icons text-sm ml-1">
                      arrow_forward
                    </span>
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default News;
