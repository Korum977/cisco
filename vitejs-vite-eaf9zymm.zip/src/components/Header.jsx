import { useLocation } from 'preact-iso';

const Header = ({ menuOpen, setMenuOpen }) => {
  const location = useLocation();

  const getPageTitle = () => {
    switch (location.path) {
      case '/':
        return 'ИвПЭК';
      case '/news':
        return 'Новости';
      case '/schedule':
        return 'Расписание';
      case '/profile':
        return 'Профиль';
      default:
        return 'ИвПЭК';
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-red-800 text-white z-40 shadow-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <button
          onClick={() => setMenuOpen(true)}
          className="material-icons p-2 hover:bg-red-900 rounded-lg transition-colors"
          aria-label="Открыть меню"
        >
          menu
        </button>
        <h1 className="text-xl font-semibold tracking-wide">
          {getPageTitle()}
        </h1>
        <button
          className="material-icons p-2 hover:bg-red-900 rounded-lg transition-colors"
          aria-label="Поиск"
        >
          search
        </button>
      </div>
    </header>
  );
};

export default Header;
