import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const Hero = () => {
  const heroRef = useRef(null);

  useEffect(() => {
    gsap.from(heroRef.current, {
      y: 30,
      opacity: 0,
      duration: 0.8,
      ease: 'power2.out',
    });
  }, []);

  return (
    <section ref={heroRef} id="hero" className="mb-8">
      <div className="bg-gradient-to-r from-red-800 to-red-900 rounded-xl text-white p-8 shadow-lg">
        <div className="space-y-3">
          <h2 className="text-2xl font-bold tracking-wide">
            Добро пожаловать в ИвПЭК
          </h2>
          <p className="text-red-100 font-medium">
            С традициями в век инноваций
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hero;
