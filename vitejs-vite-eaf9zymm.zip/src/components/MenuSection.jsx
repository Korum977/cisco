import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const MenuSection = ({ sectionId, title, icon, items }) => {
  const [isOpen, setIsOpen] = useState(false);
  const sectionRef = useRef(null);
  const listRef = useRef(null);

  useEffect(() => {
    gsap.from(sectionRef.current, {
      y: 30,
      opacity: 0,
      duration: 0.8,
      delay: 0.2,
      ease: 'power2.out',
    });
  }, []);

  useEffect(() => {
    if (isOpen && listRef.current) {
      gsap.from(listRef.current.children, {
        y: -20,
        opacity: 0,
        duration: 0.3,
        stagger: 0.05,
        ease: 'power2.out',
      });
    }
  }, [isOpen]);

  return (
    <section ref={sectionRef} id={sectionId} className="mb-8">
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-6 flex justify-between items-center hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center">
            <span className="material-icons text-red-800 text-2xl mr-3">
              {icon}
            </span>
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          </div>
          <span
            className={`material-icons text-gray-400 transition-transform duration-300 ${
              isOpen ? 'rotate-180' : ''
            }`}
          >
            expand_more
          </span>
        </button>

        {isOpen && (
          <div className="border-t border-gray-100">
            <ul ref={listRef} className="p-4 space-y-2">
              {items.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="flex items-center p-3 rounded-lg hover:bg-red-50 text-gray-700 hover:text-red-800 transition-colors"
                    target={item.external ? '_blank' : ''}
                    rel={item.external ? 'noopener noreferrer' : ''}
                  >
                    <span className="material-icons text-gray-400 mr-3 group-hover:text-red-800">
                      {item.icon}
                    </span>
                    <span className="font-medium">{item.text}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </section>
  );
};

export default MenuSection;
