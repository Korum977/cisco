import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { menuItems } from '../data/menuItems';

const OurResources = () => {
  const [isOpen, setIsOpen] = useState(false);
  const sectionRef = useRef(null);
  const listRef = useRef(null);

  useEffect(() => {
    gsap.from(sectionRef.current, {
      y: 30,
      opacity: 0,
      duration: 0.8,
      delay: 0.4,
      ease: 'power2.out',
    });
  }, []);

  useEffect(() => {
    if (isOpen && listRef.current) {
      gsap.from(listRef.current.children, {
        y: -20,
        opacity: 0,
        duration: 0.3,
        stagger: 0.05,
        ease: 'power2.out',
      });
    }
  }, [isOpen]);

  return (
    <section ref={sectionRef} id="ourResources" className="mb-8">
      {/* Similar structure to StudentServices but using menuItems.resources */}
    </section>
  );
};

export default OurResources;
