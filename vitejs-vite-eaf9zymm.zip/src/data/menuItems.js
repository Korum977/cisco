export const menuItems = {
  organization: [
    { href: '/основные-сведения', icon: 'info', text: 'Основные сведения' },
    {
      href: '/структура',
      icon: 'account_tree',
      text: 'Структура и органы управления образовательной организацией',
    },
    { href: '/документы', icon: 'description', text: 'Документы' },
    { href: '/образование', icon: 'school', text: 'Образование' },
    {
      href: '/банк-программ',
      icon: 'library_books',
      text: 'Банк адаптированных программ',
    },
    {
      href: '/стандарты',
      icon: 'gavel',
      text: 'Образовательные стандарты и требования',
    },
    {
      href: '/руководство',
      icon: 'supervised_user_circle',
      text: 'Руководство',
    },
    { href: '/педагоги', icon: 'groups', text: 'Педагогический состав' },
    {
      href: '/материально-техническое-обеспечение',
      icon: 'domain',
      text: 'Материально-техническое обеспечение и оснащенность образовательного процесса. Доступная среда',
    },
    {
      href: '/платные-услуги',
      icon: 'paid',
      text: 'Платные образовательные услуги',
    },
    {
      href: '/финансы',
      icon: 'account_balance',
      text: 'Финансово-хозяйственная деятельность',
    },
    {
      href: '/вакантные-места',
      icon: 'person_add',
      text: 'Вакантные места для приёма (перевода) обучающихся',
    },
    {
      href: '/стипендии',
      icon: 'payments',
      text: 'Стипендии и меры поддержки обучающихся',
    },
    {
      href: '/международное',
      icon: 'public',
      text: 'Международное сотрудничество',
    },
    {
      href: '/питание',
      icon: 'restaurant',
      text: 'Организация питания в образовательной организации',
    },
    { href: '/партнеры', icon: 'handshake', text: 'Партнеры' },
  ],
  student: [
    {
      href: 'https://disk.yandex.ru/d/dFUTahZmsxGDlw',
      icon: 'schedule',
      text: 'Расписание занятий (1 и 2 корпус)',
      external: true,
    },
    {
      href: 'https://disk.yandex.ru/d/hzcEilskRIbBgw',
      icon: 'schedule',
      text: 'Расписание занятий (3 корпус)',
      external: true,
    },
    {
      href: 'https://yadi.sk/d/XSpVS1vJdi43m',
      icon: 'event_note',
      text: 'Расписание экзаменов',
      external: true,
    },
    {
      href: 'https://vk.com/ssivpek',
      icon: 'groups',
      text: 'Студенческий совет',
      external: true,
    },
    { href: '/общежитие', icon: 'apartment', text: 'Общежитие' },
    { href: '/стипендия', icon: 'payments', text: 'Стипендия' },
    {
      href: '/спортивная-жизнь',
      icon: 'sports',
      text: 'Спортивно-оздоровительная деятельность',
    },
    {
      href: '/внеучебная-деятельность',
      icon: 'emoji_events',
      text: 'Внеучебная деятельность',
    },
    {
      href: '/основные-обязанности-студентов',
      icon: 'gavel',
      text: 'Основные обязанности студентов',
    },
    {
      href: '/этический-кодекс-студента',
      icon: 'policy',
      text: 'Этический кодекс студента',
    },
    {
      href: '/социально-психологическая-помощь',
      icon: 'psychology',
      text: 'Социально-психологическая помощь',
    },
    {
      href: '/перевод-с-платного-обучения-на-бесплатное',
      icon: 'swap_horiz',
      text: 'Перевод с платного обучения на бесплатное',
    },
    {
      href: 'https://yadi.sk/i/3DYQYcZ0wsnK1Q',
      icon: 'receipt',
      text: 'Квитанции для оплаты за обучение и общежитие',
      external: true,
    },
    {
      href: '/образовательный-кредит',
      icon: 'account_balance',
      text: 'Образовательный кредит',
    },
  ],
  resources: [
    { href: '/трудоустройство', icon: 'work', text: 'Трудоустройство' },
    {
      href: 'https://dl.ivpek.ru/',
      icon: 'laptop',
      text: 'Дистанционное обучение',
      external: true,
    },
    {
      href: '/автошкола-огбпоу-ивпэк',
      icon: 'directions_car',
      text: 'Автошкола',
    },
    { href: '/социальная-сеть', icon: 'share', text: 'Социальные сети' },
    {
      href: 'http://rating.ivpek.ru/',
      icon: 'analytics',
      text: 'АИС Рейтинг',
      external: true,
    },
    {
      href: '/бумц',
      icon: 'school',
      text: 'Базовый учебно-методический центр',
    },
    {
      href: '/специализированный-центр-компетенций',
      icon: 'stars',
      text: 'Специализированный центр компетенций',
    },
    {
      href: '/демоэкзамен',
      icon: 'assignment',
      text: 'Демонстрационный экзамен',
    },
    {
      href: '/центр-сертификации-профессиональных-квалификаций',
      icon: 'verified',
      text: 'Центр сертификации профессиональных квалификаций',
    },
    {
      href: 'http://special.ivpek.ru/abilympics/',
      icon: 'accessibility_new',
      text: 'Региональный центр развития движения "Абилимпикс"',
      external: true,
    },
    {
      href: '/областное-умо',
      icon: 'groups',
      text: 'Областное учебно-методическое объединение',
    },
    {
      href: '/бпоо',
      icon: 'account_balance',
      text: 'Базовая профессиональная образовательная организация',
    },
    {
      href: '/румц',
      icon: 'library_books',
      text: 'Ресурсный учебно-методический центр',
    },
  ],
};
